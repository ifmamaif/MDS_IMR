#ifndef MESH_H
	#define MESH_H
	
	#include <glm/glm.hpp>
	#include <GL/glew.h>
	class vertex
	{
		public:
			glm::vec2 texCoord;
			glm::vec3 pos;
		vertex(const glm::vec3& pos , const glm::vec2& texCoord){
			this->pos = pos;
			this->texCoord = texCoord;
		}

		inline glm::vec3* GetPos() {return &pos;}
		inline glm::vec2* GetTexCoord() {return &texCoord;}

		~vertex(){}
		protected:
		private:
			
	};

	class mesh {
		public :
			mesh(vertex* vertices, unsigned int numVertices);
			void Draw();
			~mesh();
		protected:
		private:
			mesh(const mesh& other);
			void operator=(const mesh& other);

			enum{
				POSITION_VB,
				TEXCOORD_VB,

				NUM_BUFFERS
			};

			GLuint m_vertexArrayObject;
			GLuint m_vertexArrayBuffers[NUM_BUFFERS];
			unsigned int m_drawCount;
	};

#endif // MESH_H