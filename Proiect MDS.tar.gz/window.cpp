#include "window.h"

window::window(int width=640,int height=480 , const std::string& title="Test"){
	
	SDL_Init(SDL_INIT_EVERYTHING);
    if (SDL_Init(SDL_INIT_VIDEO) < 0) // Initialize SDL's Video subsystem 
        exit(0);

    // Request opengl 3.2 context.SDL doesn't have the ability to choose which profile at this time of writing,but it should default to the core profile 
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);


	SDL_GL_SetAttribute(SDL_GL_RED_SIZE,8);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE,8);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE,8);
	SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE,8);
	SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE, 32);

    // Turn on double buffering with a 24bit Z buffer.You may need to change this to 16 or 32 for your system 
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

    // Create our window centered at 512x512 resolution 
    mainwindow = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,width, height, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN);
    if (!mainwindow) // Die if creation failed 
		exit(EXIT_FAILURE);
    

    //Create our opengl context and attach it to our window 
    maincontext = SDL_GL_CreateContext(mainwindow);


    //This makes our buffer swap syncronized with the monitor's vertical refresh 
    SDL_GL_SetSwapInterval(1);//0 for immediate updates, 1 for updates synchronized with the vertical retrace, -1 for late swap tearing; 
    
    glewExperimental = GL_TRUE; //GLEW obtains information on the supported extensions from the graphics driver. Experimental or pre-release drivers, however, might not report every available extension through the standard mechanism, in which case GLEW will report it unsupported. To circumvent this situation, the glewExperimental global switch can be turned on by setting it to GL_TRUE before calling glewInit(), which ensures that all extensions with valid entry points will be exposed.
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
	  /* Problem: glewInit failed, something is seriously wrong. */
	  fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	  exit(EXIT_FAILURE);

	}
	fprintf(stdout, "Status: Using GLEW %s\n", glewGetString(GLEW_VERSION));

	m_isClosed = false;
}

window::~window(){
	
	// Delete our opengl context, destroy our window, and shutdown SDL 
   SDL_GL_DeleteContext(maincontext);
   SDL_DestroyWindow(mainwindow);
   SDL_Quit();	
    
}

void window::Update(){
	/*
	
    glClearColor ( 1.0, 0.0, 0.0, 1.0 );	// Clear our buffer with a red background 
    glClear ( GL_COLOR_BUFFER_BIT );		// Clear our buffer
    
    SDL_GL_SwapWindow(mainwindow);			// Swap our back buffer to the front 
    	
    //SDL_Delay(2000);						// Clear our buffer

 
   //glClearColor ( 0.0, 1.0, 0.0, 1.0 );	// Clear our buffer with a green background 
   //glClear ( GL_COLOR_BUFFER_BIT );		// Clear our buffer
   //SDL_GL_SwapWindow(mainwindow);			// Swap our back buffer to the front 
   //SDL_Delay(2000);

    // Same as above, but blue 
    //glClearColor ( 0.0, 0.0, 1.0, 1.0 );	// Clear our buffer with a green background 
   // glClear ( GL_COLOR_BUFFER_BIT );		// Clear our buffer
    //SDL_GL_SwapWindow(mainwindow);		// Swap our back buffer to the front 
    //SDL_Delay(2000);
	*/

	SDL_GL_SwapWindow(mainwindow);
	SDL_Event e;

	while (SDL_PollEvent(&e)){
		if(e.type == SDL_QUIT){
			m_isClosed = true;
		}

	}
}

bool window::IsClosed(){
	return m_isClosed;
}

void window::Clear(float red=1.0f,float green=1.0f,float blue=1.0f,float alpha=1.0f){
	glClearColor(red,green,blue,alpha);
	glClear(GL_COLOR_BUFFER_BIT);
}