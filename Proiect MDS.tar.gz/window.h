#ifndef WINDOW_H
	#define WINDOW_H
	#include <SDL2/SDL.h>
	#include <iostream>
	//#include <string>
	#include <GL/glew.h>
	#include <stdlib.h>
	#include <stdio.h>
	class window {
		public:
		//window();
		window(int ,int  , const std::string&);		
		virtual ~window();
		void Update();
		bool IsClosed();
		void Clear(float,float,float,float);
	private:

		SDL_Window *mainwindow; /* Our window handle */
    	SDL_GLContext maincontext; /* Our opengl context handle */

		window(const window& other){}
		void operator=(const window& other){}

		bool m_isClosed;
	protected:

	};
#endif	//	WINDOW_H