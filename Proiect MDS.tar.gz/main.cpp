#include <iostream>
#include "window.h"
#include "shader.h"
#include "mesh.h"
#include "texture.h"
using namespace std;

// Our program's entry point 
int main(int argc, char *argv[])
{
	window main_window(600,400,"da");
	vertex vertices[] = {
		vertex(glm::vec3(-0.5	,-0.5	,0) , glm::vec2(0.0,0.0) ),
		vertex(glm::vec3(0.5	,-0.5	,0) , glm::vec2(1.0,0.0) ),
			
		vertex(glm::vec3(0		,0.5	,0) , glm::vec2(0.5,1.0) )
		
	};

	//vertex vertices[] = {
	//	vertex(glm::vec3(-1		,-1		,0)),
	//	vertex(glm::vec3(0	,0	,0)),
	//	vertex(glm::vec3(-1		,1		,0))
	//};

	mesh mmesh(vertices , sizeof(vertices) / sizeof(vertices[0]) );

	shader shader("./res/basicShader");

	//Texture mtexture("./res/texture1.jpg");
	//Texture mtexture("./res/bricks.jpg");
	Texture mtexture("./res/bd01.bmp");


	while(!main_window.IsClosed()){
		main_window.Clear(0.0f,0.15f,0.3f,1.0f);
		shader.Bind();
		mtexture.Bind();
		mmesh.Draw();
		main_window.Update();
	}
	
    return 0;
}