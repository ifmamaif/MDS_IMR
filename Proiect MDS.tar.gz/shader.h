#ifndef SHADER_H
	#define SHADER_H
	#include <string>
	#include <GL/glew.h>
	class shader {
		public:
		shader(const std::string&);		
		virtual ~shader();
		void Bind();
		
	private:
		static const unsigned int NUM_SHADERS = 2;
		shader(const shader& other){}
		void operator=(const shader& other){}
		GLuint m_program;
		GLuint m_shaders[NUM_SHADERS];
	protected:

	};
#endif	//	SHADER_H